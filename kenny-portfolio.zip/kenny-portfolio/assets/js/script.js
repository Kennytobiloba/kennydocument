window.addEventListener('DOMContentLoaded', function () {
     const text = "I code beautifully simple things and I love what I do.";
     var i = 0;
     var speed = 100;

     function writeText() {
          if (i < text.length) {
               document.getElementById("text-container").innerHTML += text.charAt(i);
               i++;

               setTimeout(writeText, speed);
          }
     }

     writeText();

     AOS.init({
          duration: 600,
          easing: 'ease-in-sine'
     });
});